import React, {Component} from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import FlexContainer from './cmp/FlexContainer.jsx';
import ImageCard from './cmp/ImageCard.jsx';
import materialImg from './img/mLogo.png';
import vendorImg from './img/cLogo.png';
import customerImg from './img/mLogo.png';
import smallHouseImg from './img/akichiSmallHouse3.png';
import largeHouseImg from './img/akichiLargeHouse2.png';
import forSaleImg from './img/akichiForSale2.png';
import approveImg from './img/approve.png';
import izelImg from './img/izel.png';

import $ from 'jquery';
import dataJson from './data/data_ja.json'

var mastersDefinition = dataJson.masters;
// TODO 画像の動的読込がしたい。画像はWeb上に配置して(どこに？)絶対URL指定なら出来るが、それだと画像のロードが入るので、出来ればコンパイルしてしまいたい。
var imageData = {
    M001: materialImg,
    M002: vendorImg,
    M003: customerImg
}

var Portal = React.createClass({
    getInitialState: function() {
        return {masterData: dataJson.masters, workData: dataJson.works, images: imageData};
    },
    render() {
        // console.info('PortalRender!!!');
        return (
            <div>
                <MuiThemeProvider muiTheme={getMuiTheme()}>
                    <ImageCard data={this.state.masterData} imageData={this.state.images}/>
                </MuiThemeProvider>
                {this.props.children}
            </div>
        );
    }
});

export default Portal;
