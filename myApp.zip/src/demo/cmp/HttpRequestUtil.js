import $ from 'jquery';


const serverHost = 'http://localhost:8080/SpringTest';
// const serverHost = '/destinations/SpringTest/';

export function callService(apiUrl, settings) {
    settings.url = serverHost + apiUrl;
    let resultData = {};
    settings.success = function(data, textStatus, jqXHR) {
            resultData = data;
        },
        settings.error = function(jqXHR, textStatus, errorThrown) {
            console.error('Service Call error');
            alert('service Error');
        }
    $.ajax(settings);
    return resultData;
}
