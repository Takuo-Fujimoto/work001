import React, {Component} from 'react';
import ReactCSSTransitionGroup from 'react/lib/ReactCSSTransitionGroup' // ES6
import './Counter.css';

class CountContainer extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            num: 0
        };
    }

    render() {
        let AwesomeNumber = <AwesomeNumber1 key={this.state.num} num={this.state.num}/>;
        if (this.state.num % 2 === 1) {
            AwesomeNumber = <AwesomeNumber2 key={this.state.num} num={this.state.num}/>;
        }

        return (
            <div className='container'>
                <ReactCSSTransitionGroup transitionName="example" transitionEnterTimeout={500} transitionLeaveTimeout={300}>
                    {AwesomeNumber}
                </ReactCSSTransitionGroup>
                <button onClick={this.handleClick.bind(this)}>Click Me!</button>
            </div>
        )
    }

    handleClick(e) {
        this.setState({
            num: this.state.num + 1
        });
    }
}

class AwesomeNumber1 extends React.Component {
    render() {
        return (
            <div className='awesome'>
                <p className='awesome1'>{this.props.num}</p>
            </div>
        );
    }
}
AwesomeNumber1.propTypes = {
    num: React.PropTypes.number.isRequired
};
class AwesomeNumber2 extends React.Component {
    render() {
        return (
            <div className='awesome'>
                <p className='awesome2'>{this.props.num}</p>
            </div>
        );
    }
}
AwesomeNumber2.propTypes = {
    num: React.PropTypes.number.isRequired
};

export default CountContainer;
